using System.Diagnostics;
using System.Reflection;
using System.Text;

namespace TestApplication
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var stringBuilder = new StringBuilder();
            stringBuilder.AppendLine("Git2SemVer test project");
            stringBuilder.AppendLine();

            var assembly = typeof(Program).Assembly;
            var informationalVersionAttribute = GetCustomAttribute<AssemblyInformationalVersionAttribute>(assembly);
            var assemblyFileInfo = FileVersionInfo.GetVersionInfo(assembly.Location);

            stringBuilder.AppendLine($"Assembly version:       {assembly.GetName().Version}");
            stringBuilder.AppendLine($"File version:           {assemblyFileInfo.FileVersion}");
            stringBuilder.AppendLine($"Informational version:  {informationalVersionAttribute!.InformationalVersion}");
            stringBuilder.AppendLine($"Product version:        {assemblyFileInfo.ProductVersion}");

            if (args.Length == 0)
            {
                Console.Write(stringBuilder.ToString());
            }
            else
            {
                var filePath = args[0];
                File.WriteAllText(filePath, stringBuilder.ToString());
            }
        }

        private static T GetCustomAttribute<T>(Assembly assembly) where T : class
        {
            return (Attribute.GetCustomAttribute(assembly, typeof(T))
                as T)!;
        }
    }
}
